import './main'
import './perfect-scrollbar'
import './preloader'
import './sidebar'
import './popover'
import './mdk-carousel-control'
import './accordion'
import './image'
import './read-more'
import './player'
import './text-scramble'
import './overlay'

(function() {
  'use strict';

  ///////////////////////////////////
  // Custom JavaScript can go here //
  ///////////////////////////////////

})()
